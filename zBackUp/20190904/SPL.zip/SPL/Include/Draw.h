// Draw Function Collection Header

#include <afxwin.h>         // MFC core and standard components
#include <EcsEnv.h>

void DrawButtonDown(CDC* pDC, CRect rect, COLORREF Color);
void DrawButton(CDC* pDC, CRect rect, COLORREF Color);
